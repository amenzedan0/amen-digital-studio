AMEN DIGITAL STUDIO - GOOGLE FLOW / GEMINI VIDEO

ئەم وەشانە بە Google Gemini Omni Flash ڤیدیۆ دروست دەکات. تێبینی: Google Flow وێبسایت/ئەپی بەرهەمهێنانی ڤیدیۆیە؛ بۆ پەیوەندی API لەناو ئەم پڕۆژەیەدا مۆدێلی فەرمی Gemini Omni Flash بەکاردێت، نەک API ـی ناوخۆی Flow.

پێداویستی: Node.js 18 یان نوێتر + کلیلی Gemini API.

١) کلیلی API لە Google AI Studio دروست بکە: https://aistudio.google.com/apikey
٢) ئەم فۆڵدەرە لە VS Code بکەرەوە.
٣) فایل .env.example کۆپی بکە و ناوی بکە .env
٤) لە ناو .env کلیلی خۆت دابنێ لە شوێنی PUT_YOUR_GOOGLE_GEMINI_API_KEY_HERE
٥) لە Terminal ئەمانە جێبەجێ بکە:
   npm install
   npm start
٦) لە وێبگەڕدا بکەرەوە: http://localhost:3000

لە بەشی GOOGLE FLOW AI VIDEO STUDIO پرۆمپتەکە بنووسە یان دەستکاری بکە؛ دەتوانیت وێنەی JPG/PNG/WEBP زیاد بکەیت. دوای تەواوبوونی دروستکردن، پێشبینینی ڤیدیۆ و دوگمەی دابەزاندنی MP4 دەردەکەوێت.

گرنگ: کلیلی API مەخە ناو HTML و لەگەڵ کەسێکی تر هاوبەشی مەکە. بەکارهێنانی Gemini API دەتوانێت سنووری بەکارهێنان یان تێچووی هەبێت. ئەم پڕۆژەیە بە تەنها کردنەوەی index.html کار ناکات؛ دەبێت server.js بە npm start کار بکات.
