require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.GEMINI_API_KEY;
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/interactions';
const VIDEO_DIR = path.join(__dirname, 'generated');
fs.mkdirSync(VIDEO_DIR, { recursive: true });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });

app.use(express.static(path.join(__dirname, 'public')));

function extractVideoData(payload) {
  for (const step of (payload.steps || [])) {
    for (const part of (step.content || [])) {
      if (part.type === 'video' && part.data) return part.data;
    }
  }
  // Support SDK-style response shapes if Google changes the REST response.
  return payload.output_video?.data || payload.outputVideo?.data || null;
}

app.post('/api/generate', upload.single('image'), async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: 'کلیلی Gemini API دانەنراوە. فایلە .env ـەکە پڕ بکەرەوە.' });
    const prompt = String(req.body.prompt || '').trim();
    if (!prompt || prompt.length > 8000) return res.status(400).json({ error: 'پرۆمپت پێویستە و نابێت لە ٨٠٠٠ پیت زیاتر بێت.' });
    const aspectRatio = ['16:9', '9:16'].includes(req.body.aspectRatio) ? req.body.aspectRatio : '16:9';
    const resolution = ['720p', '1080p', '4k'].includes(req.body.resolution) ? req.body.resolution : '720p';
    const input = [];
    if (req.file) {
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(req.file.mimetype)) {
        return res.status(400).json({ error: 'تەنها وێنەی JPG، PNG یان WEBP پشتگیری دەکرێت.' });
      }
      input.push({ type: 'image', data: req.file.buffer.toString('base64'), mime_type: req.file.mimetype });
    }
    input.push({ type: 'text', text: prompt });

    const apiResponse = await fetch(`${API_URL}?key=${encodeURIComponent(API_KEY)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gemini-omni-1.1-flash',
        input,
        response_format: { type: 'video', aspect_ratio: aspectRatio, resolution }
      }),
      signal: AbortSignal.timeout(10 * 60 * 1000)
    });
    const raw = await apiResponse.text();
    let payload;
    try { payload = JSON.parse(raw); }
    catch { throw new Error(`Google API وەڵامێکی JSON نەگەڕاندەوە (HTTP ${apiResponse.status}).`); }
    if (!apiResponse.ok) {
      const detail = payload.error?.message || payload.message || `Google API هەڵەی ${apiResponse.status}`;
      throw new Error(detail);
    }
    const videoBase64 = extractVideoData(payload);
    if (!videoBase64) {
      const status = payload.status ? ` دۆخ: ${payload.status}.` : '';
      throw new Error('Google API ڤیدیۆیەکی ئامادەی نەگەڕاندەوە.' + status + ' دڵنیابە کە Gemini API و مۆدێلەکە لە هەژمارەکەت چالاکن.');
    }
    const videoBuffer = Buffer.from(videoBase64, 'base64');
    if (!videoBuffer.length) throw new Error('داتای ڤیدیۆ بەتاڵە. تکایە دووبارە هەوڵ بدە.');
    const id = crypto.randomUUID();
    fs.writeFileSync(path.join(VIDEO_DIR, `${id}.mp4`), videoBuffer);
    res.json({ id, status: 'completed', videoUrl: `/api/video/${id}`, downloadUrl: `/api/download/${id}` });
  } catch (error) {
    console.error('Google video generation error:', error.message);
    const isTimeout = error.name === 'TimeoutError' || error.name === 'AbortError';
    res.status(isTimeout ? 504 : 500).json({ error: isTimeout ? 'دروستکردنی ڤیدیۆ زۆری خایاند. تکایە دووبارە هەوڵ بدە.' : (error.message || 'هەڵەیەک ڕوویدا.') });
  }
});

function sendVideo(req, res, download) {
  const id = String(req.params.id || '');
  if (!/^[a-f0-9-]{36}$/i.test(id)) return res.status(400).send('ناسنامەی ڤیدیۆ هەڵەیە.');
  const file = path.join(VIDEO_DIR, `${id}.mp4`);
  if (!fs.existsSync(file)) return res.status(404).send('فایلەی ڤیدیۆ نەدۆزرایەوە.');
  res.setHeader('Content-Type', 'video/mp4');
  if (download) res.setHeader('Content-Disposition', `attachment; filename="amen-flow-${id}.mp4"`);
  res.sendFile(file);
}
app.get('/api/video/:id', (req, res) => sendVideo(req, res, false));
app.get('/api/download/:id', (req, res) => sendVideo(req, res, true));

const server = app.listen(PORT, () => console.log(`AMEN DIGITAL STUDIO running at http://localhost:${PORT}`));
server.timeout = 10 * 60 * 1000;
